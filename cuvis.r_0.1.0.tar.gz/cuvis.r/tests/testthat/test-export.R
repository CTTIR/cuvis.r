test_that("ENVI export produces output files", {
  skip_if_no_sample_data()
  cuvis_init()
  withr::defer(cuvis_shutdown())

  session <- cuvis_sample_session()
  mesu <- cuvis_get_measurement(session, 1)
  ctx <- cuvis_processing_context(session)
  cuvis_reprocess(ctx, mesu, mode = "raw")

  dir <- withr::local_tempdir()
  cuvis_export_envi(mesu, dir)

  # ENVI export should produce at least one .hdr file
  hdr_files <- list.files(dir, pattern = "\\.hdr$", recursive = TRUE)
  expect_gt(length(hdr_files), 0)
})

test_that("TIFF export produces output files", {
  skip_if_no_sample_data()
  cuvis_init()
  withr::defer(cuvis_shutdown())

  session <- cuvis_sample_session()
  mesu <- cuvis_get_measurement(session, 1)
  ctx <- cuvis_processing_context(session)
  cuvis_reprocess(ctx, mesu, mode = "raw")

  dir <- withr::local_tempdir()
  cuvis_export_tiff(mesu, dir)

  tiff_files <- list.files(dir, pattern = "\\.(tif|tiff)$",
                           recursive = TRUE, ignore.case = TRUE)
  expect_gt(length(tiff_files), 0)
})

test_that("session export produces .cu3s file", {
  skip_if_no_sample_data()
  cuvis_init()
  withr::defer(cuvis_shutdown())

  session <- cuvis_sample_session()
  mesu <- cuvis_get_measurement(session, 1)

  dir <- withr::local_tempdir()
  cuvis_export_session(mesu, dir)

  cu3s_files <- list.files(dir, pattern = "\\.cu3s$",
                           recursive = TRUE, ignore.case = TRUE)
  expect_gt(length(cu3s_files), 0)
})
